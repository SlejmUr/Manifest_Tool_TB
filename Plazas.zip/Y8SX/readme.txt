This Crack works with Y8SX and up which is using upc_r2

Info what i used:
Goldberg R2 emulator (Custom Updated from V1)
Goldberg Steam emulator (Master - 802d8bcc)