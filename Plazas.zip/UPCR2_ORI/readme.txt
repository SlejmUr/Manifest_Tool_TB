This Crack works with Crystal Guard Update (Live/TTS) and up which is using UPC_R2

Info what i used:
Goldberg R2 emulator
CreamAPI Steam emulator